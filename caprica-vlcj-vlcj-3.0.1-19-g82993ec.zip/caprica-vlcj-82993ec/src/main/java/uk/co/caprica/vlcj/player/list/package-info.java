/**
 * Provides the classes necessary to create and control native media list
 * players.
 */
package uk.co.caprica.vlcj.player.list;
