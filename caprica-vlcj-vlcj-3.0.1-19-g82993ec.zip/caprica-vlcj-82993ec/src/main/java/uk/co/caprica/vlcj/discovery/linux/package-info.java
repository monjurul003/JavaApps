/**
 * Provides components that can be used to automatically discover the location
 * of the libvlc native libraries on Linux.
 */
package uk.co.caprica.vlcj.discovery.linux;
