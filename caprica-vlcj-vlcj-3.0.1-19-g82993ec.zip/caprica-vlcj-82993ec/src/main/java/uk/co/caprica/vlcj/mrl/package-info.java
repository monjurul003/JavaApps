/**
 * Provides a set of classes implementing a fluent API for creating properly
 * formatted so-called "Media Resource Locators".
 */
package uk.co.caprica.vlcj.mrl;
