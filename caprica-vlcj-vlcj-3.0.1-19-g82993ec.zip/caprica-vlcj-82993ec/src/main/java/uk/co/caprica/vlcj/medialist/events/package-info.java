/**
 * A mechanism to encapsulate native media list events and dispatch notifications
 * to event listeners.
 */
package uk.co.caprica.vlcj.medialist.events;
