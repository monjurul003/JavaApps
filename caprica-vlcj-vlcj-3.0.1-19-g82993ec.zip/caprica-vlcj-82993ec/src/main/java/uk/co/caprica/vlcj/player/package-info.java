/**
 * This is the main package for vlcj client applications, providing the classes
 * necessary to create and control native media players and associated
 * resources.
 */
package uk.co.caprica.vlcj.player;
